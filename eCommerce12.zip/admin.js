document.querySelector("form").addEventListener("submit",addProducts);

var prodBox = JSON.parse(localStorage.getItem("prodcart")) || [];

function addProducts(event) {
    event.preventDefault();
    var imageUrl = form.imgURL.value;
    var brand = form.brand.value;
    var type = form.type.value;
    var rating = form.rating.value;
    var price = form.price.value;

    var obj = {};
    obj.imageUrl = imageUrl;
    obj.brand = brand;
    obj.type = type;
    obj.rating = rating;
    obj.price = price;
    //console.log(obj);
    prodBox.push(obj);
    console.log(prodBox);
    localStorage.setItem("prodcart",JSON.stringify(prodBox));
}

document.querySelector("#btn").addEventListener("click", goToProducts);
function goToProducts() {
    window.location.href = "products.html";
}