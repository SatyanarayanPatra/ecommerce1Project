document.querySelector("form").addEventListener("submit", function() {
    goOTP(event)
});

function goOTP(event) {
    event.preventDefault();
    window.location.href = "OTP.html"
}