var body = document.querySelector("body");



var mainDiv = document.createElement("div");
mainDiv.setAttribute("id","MD");

body.append(mainDiv);

var productsCart = JSON.parse(localStorage.getItem("shopcart")) || [];

function toTalmoney()
{
    var total_money = productsCart.reduce(function (ac,el) {
        return (ac + Number(el.price))
    },0);

    console.log(total_money);

    document.getElementById("mny").innerHTML = `The total money is ${total_money} <button onclick ="checkOut()">Check Out</button>`
}

function checkOut()
{
    window.location.href = "checkOut.html"
}

displayProducts();

function displayProducts() {
    productsCart.forEach(function(item) {
        var imageDiv = document.createElement("div");

        //console.log(item.brand, item.type, item.price, item.rating);

        var image = document.createElement("img");
        image.src = item.imageUrl;

        var h1 = document.createElement("h1");
        h1.textContent = item.brand;

        var h2 = document.createElement("h2");
        h2.textContent = item.type;

        var h31 = document.createElement("h3");
        h31.textContent = item.rating;

        var h32 = document.createElement("h3");
        h32.textContent = item.price;
        imageDiv.append(image, h1, h2, h31, h32);
        mainDiv.append(imageDiv);
    });
}