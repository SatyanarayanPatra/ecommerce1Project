document.getElementById("form").addEventListener("submit",function() {
    formSubmit(event);
});

var userArr = JSON.parse(localStorage.getItem("userBox")) || [];

function formSubmit(event) {
    event.preventDefault();
    var name = form.name.value;
    var mobile = form.mobile.value;
    var email = form.email.value;
    var password = form.password.value;

    var obj = {};
    obj.name = name;
    obj.mobile = mobile;
    obj.email = email;
    obj.password = password;

    //console.log(obj);
    userArr.push(obj);
    console.log(userArr);

    localStorage.setItem("userBox", JSON.stringify(userArr));
    window.location.href = "signin.html";
}