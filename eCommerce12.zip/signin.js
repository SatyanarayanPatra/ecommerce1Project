document.querySelector("form").addEventListener("submit",function() {
    checkCredentials(event);
});

function checkCredentials(e) {
    e.preventDefault();
    var email = form.email.value;
    var password = form.password.value;
    var userArr = JSON.parse(localStorage.getItem("userBox"));

    if(email == "admin" && password == "admin") {
        window.location.href = "admin.html";
    }
    else
    {
        for(var i = 0; i < userArr.length; i++)
        {
            if(userArr[i].email == email && userArr[i].password == password)
            {
                window.location.href = "products.html";
            }
        }
        alert("Invalid credentials, retry again");
    }
}