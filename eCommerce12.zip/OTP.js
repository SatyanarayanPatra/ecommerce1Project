function otpcred() {
  var otp = document.querySelector("#otp").value;

  if (otp == "1234") {
      var h1msg = document.querySelector("#msg").innerHTML = `Order Placed <button onclick="homego()">Go to home browser</button>` 
      
  }
  else
  {
      alert("Wrong otp! Try again");
  }
}

function homego() {
    window.location.href = "home.html";
}
