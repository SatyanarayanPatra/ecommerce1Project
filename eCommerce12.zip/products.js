var body = document.querySelector("body");

var mainDiv = document.createElement("div");
mainDiv.setAttribute("id","MD");

body.append(mainDiv);

var productsCart = JSON.parse(localStorage.getItem("prodcart")) || [];

var shopCart = JSON.parse(localStorage.getItem("shopcart")) || [];

displayProducts();

function displayProducts() {
    productsCart.forEach(function(item) {
        var imageDiv = document.createElement("div");

        //console.log(item.brand, item.type, item.price, item.rating);

        var image = document.createElement("img");
        image.src = item.imageUrl;

        var h1 = document.createElement("h1");
        h1.textContent = item.brand;

        var h2 = document.createElement("h2");
        h2.textContent = item.type;

        var h31 = document.createElement("h3");
        h31.textContent = item.rating;

        var h32 = document.createElement("h3");
        h32.textContent = item.price;

        var btn = document.createElement("button");
        btn.textContent = "Add to Cart"

        btn.addEventListener("click",function() {
            addToShop(item);
        });

        imageDiv.append(image, h1, h2, h31, h32,btn);
        mainDiv.append(imageDiv);
    });
}

function addToShop(item) {
    shopCart.push(item);
    localStorage.setItem("shopcart",JSON.stringify(shopCart));
    console.log(shopCart);
}

document.getElementById("pbtn").addEventListener("click",function() {
    window.location.href = "cart.html";
})